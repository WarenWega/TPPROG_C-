#ifndef CHAMBRE_H
#define CHAMBRE_H

#include  <iostream>
#include  <string>


	

class Chambre {
public:
	
	Chambre(int idChambre , std::string type , int prix);
	int getidChambre() const;
	std::string gettype()const;
	int getprix() const;
	void updateprix(int prix);


private:
	int _idChambre;
	std::string _type;
	int _prix;
} ;

std::ostream& operator<<(std::ostream& displayList , Chambre& C);
bool operator==(const Chambre& C1, const Chambre& C2);


#endif

//std::cout<<A.idChambre()<<A.type()<<A.prix()<<std::endl;