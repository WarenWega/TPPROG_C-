#pragma once
#ifndef EMPRUNT_H_INCLUDED
#define EMPRUNT_H_INCLUDED
#include <iostream>
#include <string>
#include "lecteur.h"
#include "Date.h"

class Emprunt
{
public:
	Emprunt(int isbn, std::string idEmp, Date dat);
	void ShowEmprunt();
	bool emprunterLivre(int isbn);

private:
	int _isbn;
	std::string _idLect;
	Date _dat;
	bool _status;
};


#endif // EMPRUNT_H_INCLUDED
