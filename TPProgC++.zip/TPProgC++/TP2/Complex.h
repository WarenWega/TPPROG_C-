#include  <iostream>
#include <string>
class Complex {
	public :
	Complex();
	Complex(double a , double b ) ;
	double a();
	double b();
	double module();
	/*Complex add(Complex C);*/
	private:
		double _a ;
		double _b; 
}; 

std::string toString(Complex A);

bool test(double a , double b);