#pragma once
#ifndef DATE_H
#define DATE_H
#include <iostream>
#include <string>
using namespace std;

class Date {
public:
	Date(int month, int day, int year);
	int month() const;
	int day() const;
	int year() const;
	void updateMonth(int month);
	void updateDay(int day);
	void updateYear(int year);


private:
	int _month;
	int _day;
	int _year;
	bool isDate(int month, int day, int year);

};

std::string DateString(Date d);

#endif
