#include "livre.h"
#include "emprunt.h"
#include "Date.h"
#include "auteur.h"
#include "emprunt.h"
#include <iostream>
using namespace std;

Livre::Livre(string titre, Auteur auteur, string langue, string genre, int isbn, Date Publication ,vector<std::string> emprunteurs) :
	_titre(titre), _langue(langue), _auteur(auteur), _isbn(isbn), _genre(genre), _Publication(Publication), _emprunteurs(emprunteurs)
{

}


void Livre::ShowLivre()
{
	cout << "titre: " << _titre << endl;
	_auteur.afficherAuteur();
	cout << "Langue: " << _langue << endl << "Genre: " << _genre << endl << "ISBN: " << _isbn << endl << "Publication: " << DateString(_Publication) << endl;
	cout << "dernier emprunteurs:";
	for (int i = 0; i < _emprunteurs.size(); i++)
	{
		cout << _emprunteurs[i] << "; ";
	}
}

string Livre::GetTitre()
{
	return _titre;
}

void Livre::afficherTitre()
{
	cout << _titre << endl;
}
bool Livre::estEgal(Livre const& b)
{
	return (_isbn == b._isbn);
}

bool operator==(Livre& a, Livre& b)
{
	return a.estEgal(b);
}

std::string  Livre::getauteur() {
	
	return _auteur.getIdAuteur(); 
}
int Livre::getisbn() {
	return _isbn;
}

void Livre::addemprunteur(string lect) {
	_emprunteurs.push_back(lect);
}

void Livre::ShowemprunteurS() {
	for (int i = 0; i < _emprunteurs.size(); i++)
	{
		cout << _emprunteurs[i] << endl ;
	}
}

bool Livre::isemprunteur(string idlect) {
	
	for (auto it =_emprunteurs.begin() ; it!= _emprunteurs.end() ; it++)
	{
		if ( *it == idlect)
		{
			return true;
			
		}
	}
	 
}