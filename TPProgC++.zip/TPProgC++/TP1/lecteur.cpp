#include "lecteur.h"
using namespace std;

Lecteur::Lecteur(string nom, string prenom, string idLecteur, vector<int> isbnsLecteur) :_nom(nom), _prenom(prenom), _idLecteur(idLecteur) , _isbnsLecteur(isbnsLecteur)
{

}

string Lecteur::getidLecteur()
{
	return _idLecteur;
}

void Lecteur::addIsbn(int isbn)
{
	_isbnsLecteur.insert(_isbnsLecteur.end(),isbn);
}
void Lecteur::delIsbn(int isbn) {
	for (auto it = _isbnsLecteur.begin(); it != _isbnsLecteur.end(); it++)
	{
		if (*it == isbn)
		{
			_isbnsLecteur.erase(it);
			break;
		}
	}
}



void Lecteur::Show_Isbns()
{
	for (auto it =_isbnsLecteur.begin() ; it != _isbnsLecteur.end(); it++) {
		cout << *it << endl;
	}
}

void Lecteur::ShowLecteur()
{
	cout << "Nom: " << _nom << endl;
	cout << "Prenom: " << _prenom << endl << "IdLecteur: " << _idLecteur << endl <<endl;
}
std::vector<int> Lecteur::getisbns() {
	return _isbnsLecteur;
}
