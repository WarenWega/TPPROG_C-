#include "Client.h"


Client::Client(std::string idClient , std::string nom , std::string prenom):_idClient(idClient),_nom(nom),_prenom(prenom){}


std::string Client::getidClient(){
	return _idClient ;
}

std::string Client::getnom(){
	return _nom ;
}

std::string Client::getprenom(){
	return _prenom ;
}

void Client::searchName(){
	std::string x ;
	std::cout<<"Entrer le nom d'un client : "<<std::endl;
	std::cin>>x ;
}

std::ostream& operator<<(std::ostream& displayList ,  Client& C){
	displayList<<"Informations du client (IdClient - Nom - Prenom) : ";
	displayList<<C.getidClient()<<" - "<<C.getnom()<<" - "<<C.getprenom()<<std::endl;
	return displayList ;
}