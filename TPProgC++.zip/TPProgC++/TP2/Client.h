#ifndef CLIENT_H
#define CLIENT_H

#include  <iostream>
#include <string>
class Client {
public: 
	Client(std::string idClient , std::string nom , std::string prenom);
	std::string getidClient();
	std::string getnom();
	std::string getprenom();
	void searchName();

private: 
	std::string _idClient;
	std::string _nom;
	std::string _prenom; 

};

std::ostream& operator<<(std::ostream& displayList , Client& C);


#endif