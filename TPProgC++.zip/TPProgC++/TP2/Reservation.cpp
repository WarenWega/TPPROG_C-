#include  <iostream>
#include  <string>
#include <assert.h> 
#include "Reservation.h"

Reservation::Reservation(date::Date dateofbegin , int numofnights , std::string idHotel , Chambre chambre , Client client) : _dateofbegin(dateofbegin),_numofnights(numofnights),_idHotel(idHotel),_idClient(client.getidClient()),_chambre(chambre){

	assert(numofnights>0 && "numofnights must be positive, please try again");
    
}



date::Date Reservation::getdateofbegin()const{
	return _dateofbegin; 
}

int Reservation::getnumofnights()const{
	return _numofnights ;
}


Chambre Reservation::getchambre()const{
	return _chambre ;
}

float Reservation::getPrix(){
	return _chambre.getprix() ;
}


std::string Reservation::getidHotel()const{
	return _idHotel;
}

int Reservation::getidChambre()const{
	return _chambre.getidChambre();
}

std::string Reservation::getidClient()const{
	return _idClient;
}

void Reservation::updateDate(date::Date newdate){
	_dateofbegin=newdate;
}

void Reservation::updateChambre(Chambre C){
	_chambre=C;
}

void Reservation::updateNumofnights(int newnum){
	_numofnights=newnum;
}

float Reservation::mtotal(){
	return (_numofnights*_chambre.getprix());
}

bool dispo( Chambre C , std::vector<Reservation>& ListofReservation, date::Date d , int num){
	for (int i=0;i <ListofReservation.size(); ++i){
		if(C==ListofReservation[i].getchambre()){
			if (!(d>ListofReservation[i].getdateofbegin()+ListofReservation[i].getnumofnights() || d+num< ListofReservation[i].getdateofbegin()))
			{
				return false;
			}
			
		}
	}
	return true; 
}

std::ostream& operator<<(std::ostream& flux , Reservation& R){
	flux<<"Informations de la reservation :"<<std::endl;
	flux<<"Date de début: "<<R.getdateofbegin()<<std::endl;
	flux<<"Nombre de nuits: "<<R.getnumofnights()<<std::endl;
	flux<<"Identifiant de l'Hôtel: "<<R.getidHotel()<<std::endl;
	flux<<"Identifiant de chambre: "<<R.getidChambre()<<std::endl;
	flux<<"Identifiant de client: "<<R.getidClient()<<std::endl;
	flux<<"Montant total: "<<R.mtotal()<<std::endl;
	return flux ;
}


void Reservation::operator=(const Reservation& R){
	_dateofbegin=R.getdateofbegin();
	_numofnights=R.getnumofnights();
	_idHotel=R.getidHotel();
	_chambre=R.getchambre();
	_idClient=R.getidClient();
}