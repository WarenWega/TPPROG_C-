#ifndef RESERVATION_H
#define RESERVATION_H

#include  <iostream>
#include  <string>
#include "vector"
#include "date.h"
#include "Chambre.h"
#include "Client.h"


class Reservation{
	public:
		Reservation(date::Date dateofbegin , int numofnights , std::string idHotel , Chambre chambre , Client client);
		date::Date getdateofbegin()const;
		int getnumofnights()const;
		std::string getidHotel()const;
		int getidChambre()const;
		std::string getidClient()const;
		void updateDate(date::Date newdate);
		void updateNumofnights(int newnum);
		float mtotal();
		float getPrix();
		Chambre getchambre()const;
		void updateChambre(Chambre C);
		void operator=(const Reservation& R);
		

	private:
		date::Date _dateofbegin;
		int _numofnights;
		std::string _idHotel;
		std::string _idClient;
		Chambre _chambre;

};

bool dispo( Chambre C , std::vector<Reservation>& ListofReservation , date::Date d , int num);
std::ostream& operator<<(std::ostream& flux , Reservation& R);


#endif