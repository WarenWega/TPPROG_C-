#include "library.h"
#include "Date.h"
#include "livre.h"
#include "emprunt.h"
#include "auteur.h"
#include "lecteur.h"
#include <vector>
#include <string>
using namespace std;


Library::Library()
{

}


void Library::AjouterLivre(Livre liv)
{
	m_livres.push_back(liv);
}

void Library::AjouterLecteur(Lecteur lect)
{
	m_lecteurs.push_back(lect);
}

void Library::AjouterAuteur(Auteur aut)
{
	m_auteurs.push_back(aut);
}


vector<Livre> Library::getLivres()
{
	return m_livres;
}


void Library::afficherLivres()
{
	cout << "Liste des livres" << endl;
	for (int i = 0; i < m_livres.size(); i++)
	{
		m_livres[i].afficherTitre();
	}
}

void Library::afficherLecteurs()
{
	cout << "Liste des Lecteurs" << endl;
	for (int h = 0; h < m_lecteurs.size(); h++) {
		m_lecteurs[h].ShowLecteur();
	}
}

void Library::ShowAuteurs()
{
	cout << "Liste des Auteurs" << endl;
	for (int w = 0; w < m_auteurs.size(); w++) {
		m_auteurs[w].afficherAuteur();
	}
}


bool Library::estPresent(Livre& x)
{
	for (int i = 0; i < m_livres.size(); i++)
	{
		if (m_livres[i] == x)
		{
			cout << "Le livre est pr�sent dans la bibliotheque" << endl;
			return true;
		}

		else
			cout << "Le livre est emprunt� et pas encore rendu " << endl;
		return false;
	}
}


void Library::RestituerLivre(Livre l, Lecteur &lect)
{
	if (l.isemprunteur(lect.getidLecteur()))
	{
		for (auto it = m_livresempruntes.begin(); it != m_livresempruntes.end(); it++)
		{
			if (*it == l)
			{
				lect.delIsbn(l.getisbn());
				m_livres.push_back(l);
				m_livresempruntes.erase(it);
				break;
			}
		}
	}
	else
	{
		cout << "tu ne peux pas restituer ce livre" << endl;
	}
}


void Library::EmprunterLivre(Livre livre, Lecteur &lect)
{
	
	for (auto it = m_livres.begin(); it != m_livres.end(); it++)
	{
		if (*it == livre)
		{
			m_livresempruntes.push_back(*it);
			lect.addIsbn(6399);
			m_livres.erase(it);
			break;
		}
	}
	
}
//fonction qui permet l'afichage des livre d'un auteur :
void Library::livre_dun_auteur(string idaut)
{
	for (int i = 0; i < m_livres.size(); i++)
	{
		if (m_livres[i].getauteur() == idaut)
		{
			cout << m_livres[i].GetTitre() << endl;

		}
	}
	for (int i = 0; i < m_livresempruntes.size(); i++)
	{
			if (m_livresempruntes[i].getauteur() == idaut)
			{
				cout << m_livresempruntes[i].GetTitre() << endl;

			}
		
	}
}
void Library::livresempruntes() {
	auto todel = m_livresempruntes.begin();
	for (auto it = m_livresempruntes.begin(); it != m_livresempruntes.end(); it++)
	{
		cout << it->GetTitre() << endl;
	}
	int nbrx = m_livres.size();
	int nbry = m_livresempruntes.size();
	cout << "pourcentage de livres emprunt�s: " << (nbry* 100)/(nbrx+nbrx) << "%" << endl;
}
void Library::livre_dun_lecteur(string idlect) {

	for (auto it = m_lecteurs.begin(); it != m_lecteurs.end(); it++)
	{	

		if ((*it).getidLecteur() == idlect)
		{
			vector<int> x = (*it).getisbns();
			for (auto jt = x.begin(); jt != x.end(); jt++)
			{
				for (auto jk = m_livresempruntes.begin(); jk != m_livresempruntes.end(); jk++)
				{
					if (*jt == (*jk).getisbn())
					{
						cout << (*jk).GetTitre() << endl;
					}
				}
			}
		}
	}
}

void Library::classementdeslecteurs() {
	int min, i, j, p;
	int taille = m_lecteurs.size();
	for (i = 0; i < taille - 1; i++) {
		p = i;
		min = (m_lecteurs[i].getisbns()).size();
		for (j = i + 1; j < taille; ++j) {
			if ((m_lecteurs[j].getisbns()).size() < min)
			{
				min = (m_lecteurs[j].getisbns()).size();
				p = j;
			}
		}
		if (min != (m_lecteurs[i].getisbns()).size())
		{
			std::swap(m_lecteurs[i], m_lecteurs[p]);
		}
	}

	for (i = 0; i < taille; i++) {
		cout << i + 1 << "lecteur: " << endl;
		m_lecteurs[i].ShowLecteur();
		cout << endl;
	}
}

