#include "auteur.h"
#include "Date.h"
#include <iostream>

using namespace std;

Auteur::Auteur(string nom, string prenom, string idAuteur, Date naissance) :_nom(nom), _prenom(prenom), _idAuteur(idAuteur), _birth(naissance) {}

void Auteur::afficherAuteur()
{
	cout << "auteur: " << _nom << " " << _prenom << "; " << "date de naissance : " << DateString(_birth) << "; "<< "identifiant :" << _idAuteur << endl;
}

string Auteur::getIdAuteur()
{
	return _idAuteur;
}

Date Auteur::getDateNaissance()
{
	return _birth;
}
