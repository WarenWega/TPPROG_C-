#include "emprunt.h"
#include "Date.h"
#include "lecteur.h"
using namespace std;


Emprunt::Emprunt(int isbn, string idLect, Date dat) :_isbn(isbn), _idLect(idLect), _dat(dat), _status(false)
{

}

void Emprunt::ShowEmprunt()
{
	cout << endl << "etiquette d'emprunt: " << endl;
	cout << "ISBN: " << _isbn << ";  " << "idEmp: " << _idLect << ";  "  << "Date d'emprunt: " << DateString(_dat) << endl;
}

bool Emprunt::emprunterLivre(int isbn)
{
	if (_status)
	{
		return false;
	}
	else
	{
		return true;
	}
}
