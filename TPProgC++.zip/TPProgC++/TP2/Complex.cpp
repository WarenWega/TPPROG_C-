#include  <iostream>
#include "Complex.h"
#include <cmath>
#include <string>
#include <assert.h>

Complex::Complex(double a , double b):_a(a),_b(b){
	bool status =  test( a , b);
        assert(status && "Entrez des valeurs positives pour a et b");
}

double Complex::a() {
	return _a ; 
}

double Complex::b() {
	return _b ;
}

Complex::Complex(){

}

double Complex::module() {
	return sqrt (a()*a()+b()*b());
}

std::string toString (Complex A){
	if(A.a()==0){
		return "i"+std::to_string(A.b());
	}
	else if(A.b()==0){
		return std::to_string(A.a());
	}else{
		return std::to_string(A.a())+" + i"+std::to_string(A.b());
	}
}

/*Complex Complex::add(Complex C){
	Complex c3 ; 
	c3.a()= a()+C.a();
	c3.b()= b();
	return c3;
}
*/

bool test(double a , double b){
	if(a<0 || b<0){
		return false ;
	} else {
		return true ; 
	}

}