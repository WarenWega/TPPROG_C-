#ifndef HOTEL_H
#define HOTEL_H


#include  <iostream>
#include  <string>
#include  <vector>
#include "Chambre.h"
#include"Reservation.h"

class Hotel {
public:
	Hotel(std::string idHotel , std::string nomHotel , std::string ville , std::vector<Chambre> listofchambre );
	std::string getidHotel();
	std::string getnomHotel ();
	std::string getville();
	std::vector<Chambre> listofchambre();
	std::vector<Reservation> ListofReservation();
	void delChambre(int i);
	void addChambre(Chambre A); 
	void affChambre();
	int takeReservation();
	void addReservation(Reservation R);
	void removeReservation();
	void afficheReservation();
	void afficheReservationNum(int k);
	void searchReservation(std::string nom);
	int updateReservation(int numero);
	void affc(int i);


private:
	std::string _idHotel;
	std::string _nomHotel; 
	std::string _ville; 
	std::vector<Chambre> _listofchambre;
	std::vector<Reservation> _ListofReservation;
};

std::ostream& operator<<(std::ostream& displayList , Hotel& H);

#endif