#include  <iostream>
#include  "Hotel.h"

Hotel::Hotel(std::string idHotel , std::string nomHotel , std::string ville , std::vector<Chambre> listofchambre ) : _idHotel(idHotel),_nomHotel(nomHotel),_ville(ville),_listofchambre(listofchambre){}


std::string Hotel::getidHotel(){
	return _idHotel;
}

std::string Hotel::getnomHotel (){
	return _nomHotel;
}

std::string Hotel::getville(){
	return _ville;
}

std::vector<Chambre> Hotel::listofchambre(){
    return _listofchambre; 
}

std::vector<Reservation> Hotel::ListofReservation(){
    return _ListofReservation; 
}

void Hotel::addReservation(Reservation R){
	_ListofReservation.push_back(R);
}

void Hotel::delChambre(int i){
	auto l = _listofchambre.begin();
	l += i;
	_listofchambre.erase(l);
}

void Hotel::addChambre(Chambre A){
	_listofchambre.push_back(A);
}

void Hotel::affc(int i){
	std::cout << "\nIdChambre de la chambre sélectionnée: " <<_listofchambre[i].getidChambre()<< std::endl;
	std::cout << "\nPrix de la chambre sélectionnée: " <<_listofchambre[i].getprix()<< std::endl;
}


void Hotel::afficheReservation(){
	int l=0;
	for(;l<_ListofReservation.size();l++){
		std::cout<<"Reservation"<<"("<<l<<")"<<std::endl;
		std::cout<<_ListofReservation[l]<<std::endl;
	}
}



void Hotel::afficheReservationNum(int k){
		std::cout<<_ListofReservation[k]<<std::endl;
}

void Hotel::removeReservation(){
	int delnumber;
	std::string idClient;
	std::cout<<"Vous souhaitez annuler votre reservation ? Entrer votre idCLient :"<<std::endl;
	std::cin>>idClient;
	std::cout<<"Ci-dessous vos différentes réservations dans notre Hotel."<<std::endl;
	searchReservation(idClient);
	std::cout<< "Veuillez entrer le numéro de la Reservation à annuler!!!" <<std::endl ;
	std::cin>>delnumber;
	_ListofReservation.erase(_ListofReservation.begin()+delnumber);
	afficheReservation();
}

void Hotel::searchReservation(std::string nom){
	int l=0;
	for(;l<_ListofReservation.size();l++){
		if (nom==_ListofReservation[l].getidClient())
		{
			std::cout<<"Reservation"<<"("<<l<<")"<<std::endl;
			std::cout<<_ListofReservation[l]<<std::endl;
		}
	}
}

int Hotel::updateReservation(int numero){
	Reservation r = _ListofReservation[numero];
	std::string typ = r.getchambre().gettype();
	int month;
	int day;
	int year;
	int num;
	char o1;
	char o2;
	char o3;
	char o4;
	int a;
	std::cout<< "Souhaitez vous modifier la date ? (Y/N) " <<std::endl ;
	std::cin>>o1;
	if (o1=='Y')
	{
			std::cout<< "Entrez la nouvelle date: ( mois , jour , année)" <<std::endl ;
			std::cin>>month;
			std::cin>>day;
			std::cin>>year;
			date::Date d(month,day,year);
			r.updateDate(d);
	}
	std::cout<< "Souhaitez vous modifier le nombre de nuits ? (Y/N) " <<std::endl ;
	std::cin>>o2;
	if (o2=='Y')
	{
		do{
			std::cout<< "Entrez le nombre de nuits" <<std::endl ;
			std::cin>>num;
			if(num<0){
				std::cout<< "Entrez un nombre positif!!!" <<std::endl ;
			}
		}while(num<0);
		r.updateNumofnights(num);
	}
	std::cout<< "Souhaitez vous modifier le type de chambre ? (Y/N)" <<std::endl ;
	std::cin>>o3;
	if (o3=='Y')
	{
		std::cout<< "Quel type de chambre désirez vous ? (Single,Double,Suite)" <<std::endl ;
		std::cin>>typ;	
	}

	for(int i=0;i <_listofchambre.size();i++){
		if(typ==_listofchambre[i].gettype()){
			if (dispo(_listofchambre[i],_ListofReservation,r.getdateofbegin(),r.getnumofnights())==true)
			{
				r.updateChambre(_listofchambre[i]);
				_ListofReservation[numero]=r;
				return i ;
			}
	
	}	
		//throw "Reservation Impossible, pas de chambre disponible pour cette période!!!";
		}

	throw "Reservation Impossible, pas de chambre disponible pour cette période!!!";
}


void Hotel::affChambre(){
	int l=0;
	for(;l<_listofchambre.size();l++){
		std::cout<<_listofchambre[l].getidChambre()<<std::endl;
	}
}



std::ostream& operator<<(std::ostream& displayList , Hotel& H){
	displayList<<"Informations de l'Hôtel (IdHotel - Nom - Ville - Ensemble de chambres) : ";
	displayList<<H.getidHotel()<<" - "<<H.getnomHotel()<<" - "<<H.getville()<<std::endl;
	for(int i=0;i<H.listofchambre().size();i++){
	displayList<<H.listofchambre()[i];
	 }
	return displayList ;
}


int Hotel::takeReservation(){
	int month;
	int day;
	int year;
	int num;
	std::string typ;
	std::cout<< "Entrez la date prévu: ( mois , jour , année)" <<std::endl ;
	std::cin>>month;
	std::cin>>day;
	std::cin>>year;
	date::Date d(month,day,year);
	do{
			std::cout<< "Entrez le nombre de nuits" <<std::endl ;
			std::cin>>num;
			if(num<0){
				std::cout<< "Entrez un nombre positif!!!" <<std::endl ;
			}
		}while(num<0);
	std::cout<< "Quel type de chambre désirez vous ? (Single,Double,Suite)" <<std::endl ;
	std::cin>>typ;

	for(int i=0;i <_listofchambre.size();i++){
		if(typ==_listofchambre[i].gettype()){
			if (dispo(_listofchambre[i],_ListofReservation,d,num)==true)
			{
				return i ;
			}
		}
	
	
	}

		throw "Pas de Chambre ";

}
