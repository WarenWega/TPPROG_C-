#pragma once
#ifndef LECTEUR_H_INCLUDED
#define LECTEUR_H_INCLUDED

#include <iostream>
#include <string>
#include <vector>


class Lecteur
{
public:
	
	Lecteur(std::string nom, std::string prenom, std::string idLecteur, std::vector<int> isbnsLecteur);
	std::string getidLecteur();
	void addIsbn(int isbn);
	void delIsbn(int isbn);
	void Show_Isbns();
	std::vector<int> getisbns();
	void ShowLecteur();

private:
	std::string _idLecteur;
	std::string _nom;
	std::string _prenom;
	std::vector<int> _isbnsLecteur;
};

#endif
