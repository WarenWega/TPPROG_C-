#include <iostream>
#include "Reservation.h"
#include "date.h"
#include "Client.h"
#include "Chambre.h"
#include "Hotel.h"


void recherche(std::vector<Client>& T);
void affiche(std::vector<Client>& T);
	void recherche(std::vector<Client>& T)
	{
		std::string lastname; 
		bool here = false;
		std::cout<< "Entrez le nom du client" <<std::endl ;
		std::cin>>lastname;
		for (int i = 0; i <T.size(); ++i){
		if (T[i].getnom()==lastname){
		here=true;
		std::cout<<T[i]<<std::endl;
		}
		
	}
		if(here==false){
			std::string id;
			std::string firstname;
			std::cout<<"Le client ne trouve pas dans notre base de données.Nous avons besoin de plus d'informations!!!"<<std::endl;
			std::cout<<"Entrer l'IdClient:"<<std::endl;
			std::cin>>id;
			std::cout<<"Entrer le prénom du client:"<<std::endl;
			std::cin>>firstname;
			Client k(id,lastname,firstname);
			T.push_back(k);
		}
	}

void affiche(std::vector<Client>& T){
	for (int i = 0; i <T.size(); ++i){
		std::cout<<T[i]<<std::endl;
		}
}

int main (int argc, char const *argv[]) {
	//int M ;
	bool test;
	
	//std::vector<Client> T;
	std::string idClient;
	int numero;
   


	std::cout << "\n ----------------------------------------------------------------------  PARTIE 1: CREATION DES CLASSES ------------------------------------------------------------------------- " <<  std::endl;

	std::cout << "\n ----------------------  Programme de test de la classe Date (mm-jj-aa) -------------------- " <<  std::endl;
	date::Date d1(2,6,2021);
	date::Date d2(2,5,2021);
	date::Date d3(2,1,2021);
	std::cout<<d1<<std::endl;
	std::cout<<d2<<std::endl;
	std::cout<<d3<<std::endl;
	

	std::cout << "\n ----------------------  Programme de test de la classe Client (IdClient-Nom-Prenom) -------------------- " <<  std::endl;
	Client customer("first","Einstein","Albert");
	std::cout << "\nIdClient: " <<customer.getidClient()<< std::endl;
	std::cout << "\nNom: " <<customer.getnom()<< std::endl;
	std::cout << "\nPrenom: " <<customer.getprenom()<< std::endl;



	std::cout << "\n ----------------------  Programme de test de la classe Chambre (IdChambre-Type-Prix) -------------------- " <<  std::endl;
	Chambre room(203,"Single",100);
	std::cout << "\nIdChambre: " <<room.getidChambre()<< std::endl;
	std::cout << "\nType: " <<room.gettype()<< std::endl;
	std::cout << "\nPrix: " <<room.getprix()<< std::endl;
	room.updateprix(40);
	std::cout << "\nModification du prix: " <<room.getprix()<< std::endl;


	
	std::cout << "\n ----------------------  Programme de test de la classe Hôtel (Idhotel-Nom-Ville-Ensemble de chambres) -------------------- " <<  std::endl;
	std::vector<Chambre> vector;
	Hotel M("OCEAN11","Le Bellagio","Las Vegas", vector);
	Chambre room1(203,"Single",100);
	Chambre room2(204,"Suite",500);
	std::cout << "\nIdHotel: " <<M.getidHotel()<< std::endl;
	std::cout << "\nNom: " <<M.getnomHotel()<< std::endl;
	std::cout << "\nVille: " <<M.getville()<< std::endl;
	//Ajout d'une chambre
	M.addChambre(room1);
	M.addChambre(room2);
	//Affichage du tableau vector
	std::cout << "\nEmsemble des IdChambres de l'Hotel (après ajout de chambres)"<< std::endl;
	M.affChambre();
	//Suppresion d'une chambre
	M.delChambre(0);
	//Affichage du tableau vector
	std::cout << "\nEmsemble des IdChambres de l'Hotel (après suppression d'une chambre)"<< std::endl;
	M.affChambre();



	std::cout << "\n ----------------------  Programme de test de la classe Reservation (Date de début-Nombre de Nuits-IdHotel-IdChambre-IdClient-Montant total) -------------------- " <<  std::endl;
	Reservation reser(d1,2,M.getidHotel(),room1,customer);
	std::cout << "\nDate de début: " <<reser.getdateofbegin()<< std::endl;
	std::cout << "\nNombre de nuits: " <<reser.getnumofnights()<< std::endl;
	std::cout << "\nIdHotel: " <<reser.getidHotel()<< std::endl;
	std::cout << "\nIdChambre: " <<reser.getidChambre()<< std::endl;
	std::cout << "\nIdClient: " <<reser.getidClient()<< std::endl;
	std::cout << "\nMontant total: " <<reser.mtotal()<< std::endl;
	//Modification de la date
	reser.updateDate(d2);
	std::cout << "\nNouvelle date de début: " <<reser.getdateofbegin()<< std::endl;
	//Modification du nombre de nuits
	reser.updateNumofnights(5);
	std::cout << "\nNouvelle valeur du nombre de nuits: " <<reser.getnumofnights()<< std::endl;
	//Calcul du montant total de la reservation avec les nouveaux paramètres
	std::cout << "\nMontant total: " <<reser.mtotal()<< std::endl;


std::cout << "\n --------------------------------------------------------- PARTIE 2: UTILISATION DES CLASSES DANS UNE APPLICATION --------------------------------------------------- " <<  std::endl;


	std::cout << "\n ----------------------  Création d'un hôtel et de clients -------------------- " <<  std::endl;
	std::vector<Client> T;
	std::vector<Chambre> c;
	Hotel H("OCEAN11","Le Bellagio","Las Vegas", c);


	//Création des chambres
	Chambre ch1(2000,"Single",100);
	Chambre ch2(2001,"Single",100);
	Chambre ch3(2002,"Single",100);
	Chambre ch4(2003,"Double",125);
	Chambre ch5(2004,"Double",125);
	Chambre ch6(2005,"Double",125);
	Chambre ch7(2006,"Double",125);
	Chambre ch8(2007,"Double",125);
	Chambre ch9(2008,"Suite",210);
	Chambre ch10(2009,"Suite",210);

	//Ajout des chambres à l'Hôtel
	H.addChambre(ch1);
	H.addChambre(ch2);
	H.addChambre(ch3);
	H.addChambre(ch4);
	H.addChambre(ch5);
	H.addChambre(ch6);
	H.addChambre(ch7);
	H.addChambre(ch8);
	H.addChambre(ch9);
	H.addChambre(ch10);

	//Surcharge de l'operateur << à la classe Chambre
	std::cout << "\n*********Affichage des d'informations des differentes chambres*********"<< std::endl;
	std::cout <<ch1<< std::endl;
	std::cout <<ch2<< std::endl;
	std::cout <<ch3<< std::endl;
	std::cout <<ch4<< std::endl;
	std::cout <<ch5<< std::endl;

	//Surcharge de l'operateur << à la classe Hôtel
	std::cout << "\n*********Affichage des d'informations de l'Hôtel*********"<< std::endl;
	std::cout <<H<<std::endl;


	//Création des clients
	Client clt1("one","amana","omar");
    Client clt2("two","mba","waren");
    Client clt3("three","cosson","tom");


    //Ajout des clients
    T.push_back(clt1);
    T.push_back(clt2);
    T.push_back(clt3);


    //Surcharge de l'operateur << à la classe Client
    std::cout << "\n*********Affichage des informations des clients*********"<< std::endl;
	std::cout <<clt1<< std::endl;
	std::cout <<clt2<< std::endl;


	//Recherche d'un client et ajout si abscence
	//recherche(T);

	//std::cout << "\n*********Affichage de la liste des clients pour verification*********"<< std::endl;
	//affiche(T);


	//Prendre une reservation
	/*try{
		int i=H.takeReservation();
		H.affc(i);
	}
	
	catch (char const*& message){

		std::cout<<"Pas de chambre disponible pour cette période!!!"<<std::endl;
	}*/



	std::cout << "\n ----------------------  Création de la reservation  -------------------- " <<  std::endl;

	//Creation de nouvelles dates
	date::Date a(2,6,2021);
	date::Date b(2,5,2021);
	date::Date i(2,1,2021);

	//Calcul et affichage du prix exact du séjour
	std::cout<<"Prix exact du séjour"<<" : "<<reser.mtotal()<<std::endl;


	//Creation des reservations
	Reservation R1(a,2,H.getidHotel(),ch1,clt1);
	Reservation R2(b,8,H.getidHotel(),ch2,clt2);
	Reservation R4(b,5,H.getidHotel(),ch4,clt2);

	//Ajout d'une reservation et affichage
	H.addReservation(R1);
	H.addReservation(R2);
	H.addReservation(R4);
	std::cout<<R1;
	



	std::cout << "\n ----------------------  Gestion des reservations  -------------------- " <<  std::endl;

	//Afficher les réservations de l'hôtel
	//H.afficheReservation();

	//Afficher les réservations de l'hôtel avec un identifiant 
	//H.afficheReservationNum(1);


	//Afficher toutes les réservations d'un client en passant l'Id comme argument
	//H.searchReservation("one");


	//Modifier une réservation
	std::cout<<"Vous souhaitez modifier votre reservation ? Entrer votre idCLient :"<<std::endl;
	std::cin>>idClient;
	std::cout<<"Ci-dessous vos différentes réservations dans notre Hotel."<<std::endl;
	H.searchReservation(idClient);
	std::cout<<" Veuillez entrer le numero de réservation correspondant à celle que vous souhaitez modifier!!!"<<std::endl;
	std::cin>>numero;
	std::cout<<" Vous souhaitez modifier la réservation"<<"("<<numero<<")."<<std::endl;
	H.afficheReservationNum(numero);
	try{
		H.updateReservation(numero);
	}
	
	catch (char const*& message){

		std::cout<<"Reservation Impossible, pas de chambre disponible pour cette période!!!"<<std::endl;
	}


	H.afficheReservation();

	//Annuler une reservation
	//H.removeReservation();
	

	return 0 ;
}




