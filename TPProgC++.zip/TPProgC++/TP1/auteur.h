#pragma once
#ifndef AUTEUR_H_INCLUDED
#define AUTEUR_H_INCLUDED

#include <string>
#include <iostream>
#include "Date.h"


class Auteur
{
public:
	Auteur(std::string nom, std::string prenom, std::string idAuteur, Date naissance);
	void afficherAuteur();
	std::string getIdAuteur();
	Date getDateNaissance();

protected:
	std::string _nom;
	std::string _prenom;
	std::string _idAuteur;
	Date _birth;

};

#endif // AUTEUR_H_INCLUDED
