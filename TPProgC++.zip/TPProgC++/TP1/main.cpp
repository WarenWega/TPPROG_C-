#include <iostream>
#include <vector>
#include <string>
#include "Date.h"
#include "livre.h"
#include "emprunt.h"
#include "auteur.h"
#include "lecteur.h"
#include "library.h"

using namespace std;

int main()
{
	cout << "-----------------------------------Premiere Partie----------------------------------------- " << endl;
	// Qestion 1 class date:
	cout << "programme test de la class Date: " << endl;

	Date a(01, 01, 1915), b(01, 03, 1892), c(02, 26, 1802), d(05, 25, 1954), e(07, 29, 1954), f(02, 01, 1829), g(7, 01, 1977), h(12, 02, 2012), i(8, 22, 1956), j(7, 9, 2010), k(06, 21, 2000), l(04, 20, 2001), m(6, 12, 1956);
	
	//la fonction datestring permet de transformer la date au format jour/mois/ann� 
	cout << DateString(a) << endl ;
	cout << DateString(d) << endl;

	// Qestion 2 class livre et auteur:
	cout <<endl<< "---------programme de test des class auteur et livre -----------";

	Auteur auteur1("Ahmed", "Sefrioui", "ahmedsef", a), auteur2("John Ronald Reuel", "Tolkien", "jrrtolkien", b), auteur3("Victor ", "Hugo", "vihugo", c), auteur4("mohamed", "njem", "njem15", e), auteur5("manuel", "eto", "etor2", h);
	
	Livre Livre1("La Bo�te � merveilles", auteur1, "Francais", "Roman Autobiographique", 6399, d, {});
	Livre Livre2("Le Seigneur des anneaux", auteur2, "Francais", "Fiction", 1259, e, {});
	Livre Livre3("Le Dernier Jour d'un condamn�", auteur3, "Francais", "fiction", 7890, f, {});
	Livre Livre4("la terre de Zikola", auteur4, "Francais", "Roman de fiction", 1256, g, {});
	Livre Livre5(" L'�tranger", auteur1, "Francais", "Roman ", 1425, h, {});
	Livre Livre6("Voyage au bout de la nuit ", auteur5, "Francais", "Roman", 1412, i, {});
	Livre Livre7("La Horde du contrevent", auteur2, "Francais", "Roman et science-fiction", 1819, j, {});
	Livre Livre8("Le Petit Prince", auteur3, "Francais", "Conte et jeunesse", 0206, k, {});
	Livre Livre9("Les Fleurs du mal", auteur2, "Francais", "Po�sie", 1586, l, {});
	Livre Livre10("L'�cume des jours", auteur4, "Francais", "Roman", 7856, m, {});

	cout << endl << "Premier Livre:" << endl;
	Livre1.ShowLivre();
	cout << endl << endl <<"Dexi�me Livre:" << endl;
	Livre2.ShowLivre();
	cout << endl << endl << "Troisi�me Livre:" << endl;
	Livre3.ShowLivre();

	// Question 3 la class Lecteur:
	cout << endl << "--------programme de test des class Lecteur :-----------" << endl;

	Lecteur Lecteur1("BASSIM", "Mohamed Yassine", "bamoya", {}), Lecteur2("NICO ", "Roben", "nicoroben12", {}), Lecteur3("Gold De ", "Rojer", "golderoj", { 1525 });
	
	Lecteur1.ShowLecteur();
	Lecteur2.ShowLecteur();

	cout <<endl << "-------liste des ISBNS d'un Lecteur----------" << endl;
	Lecteur3.Show_Isbns();

	//question 4 la class emprunt:

	cout << endl <<"------programme de test des class Emprunt:-----------" << endl;
	
	Emprunt premier(1259, "bamoya", d);
	premier.ShowEmprunt();

	//Dexi�me Partie:
	cout << "-----------------------------------Dexi�me Partie----------------------------------------- " << endl;
	//creation des �lement de la class bibliotheque:
	//Question 5 et 6:
	Library Biblio;

	Biblio.AjouterLecteur(Lecteur1); //l'ajoutage des lecteurs
	Biblio.AjouterLecteur(Lecteur2);
	Biblio.AjouterLecteur(Lecteur3);

	Biblio.AjouterAuteur(auteur1);	//l'ajoutage des auteurs
	Biblio.AjouterAuteur(auteur2);
	Biblio.AjouterAuteur(auteur3);
	Biblio.AjouterAuteur(auteur4);
	Biblio.AjouterAuteur(auteur5);

	Biblio.AjouterLivre(Livre1); //l'ajoutage des livres
	Biblio.AjouterLivre(Livre2);
	Biblio.AjouterLivre(Livre3);
	Biblio.AjouterLivre(Livre4);
	Biblio.AjouterLivre(Livre5);
	Biblio.AjouterLivre(Livre6);
	Biblio.AjouterLivre(Livre7);
	Biblio.AjouterLivre(Livre8);
	Biblio.AjouterLivre(Livre9);
	Biblio.AjouterLivre(Livre10);


	cout <<endl << "--------affichage des elements de la bibliotheque----------" << endl; // affichagedes livres de la biblio 
	Biblio.afficherLivres();
	cout << endl;
	Biblio.afficherLecteurs();
	cout << endl;
	Biblio.ShowAuteurs();
	cout << endl;

	// empruntement des livres:
	Biblio.EmprunterLivre(Livre1, Lecteur1);
	Biblio.EmprunterLivre(Livre2, Lecteur1);
	Biblio.EmprunterLivre(Livre3, Lecteur1);
	Biblio.EmprunterLivre(Livre4, Lecteur2);
	Biblio.EmprunterLivre(Livre5, Lecteur2);
	Biblio.EmprunterLivre(Livre6, Lecteur3);

	cout << endl <<"------------la nouvelle liste des livre---------------" << endl;
	Biblio.afficherLivres();// affichagedes livres de la biblio 
	
	cout << endl << "------------liste des isbns des livres emprunt� par lecteur1-----------" << endl;
	Lecteur1.Show_Isbns();

	cout << endl<<"------------restitustion de quelques livres--------------" << endl;
	Biblio.RestituerLivre(Livre6, Lecteur3);
	Biblio.RestituerLivre(Livre5, Lecteur2);
	Biblio.RestituerLivre(Livre3, Lecteur1);

	cout << endl << "------------la nouvelle liste des livre------------" << endl;
	Biblio.afficherLivres();// affichagedes livres de la biblio 
	

	// Question 8:

	//les livres d'un auteur:
	cout << endl << "-----------livre d'un auteur-------------" << endl;
	Biblio.livre_dun_auteur("jrrtolkien");

	//liste de tous les livres emprunt�s et leurs pourcentage:
	cout << endl << "-----------livre emprunt�s-------------" << endl;
	Biblio.livresempruntes();

	//liste des livres emprunt�s par un lecteur:
	cout << endl << "-----------livre empruntes par un lecteur:-------------" << endl;
	Biblio.livre_dun_lecteur("bamoya");
	
	//classemenent des lecteursen fonction du nombre de livres emprunt�s:
	cout << endl << "--------classemenent des lecteursen fonction du nombre de livres emprunt�s-------" << endl;
	Biblio.classementdeslecteurs();
	return 0;
}
