#pragma once
#ifndef LIVRE_H_INCLUDED
#define LIVRE_H_INCLUDED
#include <iostream>
#include <string>
#include "auteur.h"
#include "Date.h"
#include "emprunt.h"


class Livre
{
public:
	Livre(std::string titre, Auteur auteur, std::string langue, std::string genre, int isbn, Date Publication, std::vector<std::string>  emprunteurs);
	void ShowLivre();
	std::string GetTitre();
	void afficherTitre();
	bool estEgal(Livre const& b);
	std::string  getauteur();
	int getisbn();
	void addemprunteur(string lect);
	void ShowemprunteurS();
	bool isemprunteur(string idlect);
private:
	std::string _titre;
	Auteur _auteur;
	std::string _langue;
	std::string _genre;
	Date _Publication;
	int _isbn;
	std::vector<std::string> _emprunteurs;
};

bool operator==(Livre& a, Livre& b);

#endif













