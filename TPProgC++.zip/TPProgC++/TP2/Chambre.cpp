#include  <iostream>
#include  <ostream>
#include  "Chambre.h"

Chambre::Chambre(int idChambre , std::string type , int prix):_idChambre(idChambre),_type(type),_prix(prix){}

int Chambre::getidChambre() const {
	return _idChambre;
}

std::string Chambre::gettype() const{
	return _type;
}

int Chambre::getprix() const{
	return _prix;
}

void Chambre::updateprix(int prix){
	_prix=prix;
}

std::ostream& operator<<(std::ostream& displayList ,  Chambre& C){
	displayList<<"Informations de la chambre (IdChambre - Type - Prix par nuit) : ";
	displayList<<C.getidChambre()<<" - "<<C.gettype()<<" - "<<C.getprix()<<std::endl;
	//<<";"<<C.type()<<";"<<C.prix();
	return displayList ;
}


bool operator==(const Chambre& C1 , const Chambre& C2){
	if(C1.getidChambre()==C2.getidChambre() && C1.gettype()==C2.gettype() && C1.getprix()==C2.getprix()){
		return true; 
	}else{
		return false;
	}
	 
}