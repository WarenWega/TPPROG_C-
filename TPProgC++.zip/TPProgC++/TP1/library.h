#pragma once
#ifndef LIBRARY_H_INCLUDED
#define LIBRARY_H_INCLUDED
#include <vector>
#include <string>
#include "livre.h"
#include "lecteur.h"
#include "auteur.h"
#include "emprunt.h"
#include "Date.h"


class Library
{
public:
	Library();
	void AjouterLivre(Livre liv);
	void AjouterLecteur(Lecteur lect);
	void AjouterAuteur(Auteur aut);
	std::vector<Livre> getLivres();
	void afficherLivres();
	void afficherLecteurs();
	void ShowAuteurs();
	bool estPresent(Livre& x);
	void EmprunterLivre(Livre livre, Lecteur &lect);
	void RestituerLivre(Livre l, Lecteur &lect);
	void livre_dun_auteur(string idaut);
	void livresempruntes();
	void livre_dun_lecteur(string idlect);
	void classementdeslecteurs();
private:
	std::vector<Livre> m_livres;
	std::vector<Lecteur> m_lecteurs;
	std::vector<Auteur> m_auteurs;
	std::vector<Emprunt> m_emprunts;
	std::vector<int> m_isbns;
	std::vector<Livre> m_livresempruntes;
	
};



#endif
